// src/main.jsx
import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import App from './App'; // your landing/main page
import RoleSelection from './pages/RoleSelection';
import AuthPage from './pages/AuthPage'; // Import the new AuthPage component
import AdminLogin from './pages/auth/AdminLogin';
import DoctorLogin from './pages/auth/DoctorLogin';
import DoctorRegister from './pages/auth/DoctorRegister';
// Add this import
import AdminDashboard from './pages/auth/AdminDashboard';

// Add this route

import "./index.css";
import GenAiSearch from './genai/GenAiSearch';
import Home from './App';



ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<App />} />
        <Route path="/select-role" element={<RoleSelection />} />
        <Route path="/auth" element={<AuthPage />} /> {/* Add this line */}
        <Route path="/admin/login" element={<AdminLogin />} />
        <Route path="/doctor/login" element={<DoctorLogin />} />
        <Route path="/doctor/register" element={<DoctorRegister />} />
        <Route path="/search/:query" element={<GenAiSearch />} />
        <Route path="/auth/dashboard" element={<AdminDashboard />} />
        
      </Routes>
    </BrowserRouter>
  </React.StrictMode>
);