/** @type {import('tailwindcss').Config} */
export default {
    content: [
      "./index.html",
      "./src/**/*.{js,ts,jsx,tsx}",
    ],
    theme: {
      extend: {
        colors: {
          softblue: "#f0f8ff",
          primary: "#00bfa6",
          accent: "#007bff",
          muted: "#eaeaea",
        },
        fontFamily: {
          sans: ["Poppins", "sans-serif"],
        }
      },
    },
    plugins: [],
  }